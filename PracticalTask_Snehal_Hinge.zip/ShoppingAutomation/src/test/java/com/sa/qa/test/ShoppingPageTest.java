package com.sa.qa.test;


import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sa.qa.base.BaseTest;
import com.sa.qa.pages.HomePage;
import com.sa.qa.pages.LoginPage;
import com.sa.qa.pages.ShoppingPage;

public class ShoppingPageTest extends BaseTest {

	LoginPage loginpage;
	ShoppingPage shoppingpage;
	HomePage homepage;
	public ShoppingPageTest(){
		super();
	}
	
	@BeforeMethod
	public void setUp(){
		initialization();
		shoppingpage = new ShoppingPage();	 
		homepage = new HomePage();
		System.out.println("User is going to click on SignIn Button");
		loginpage= homepage.ValidateLoginbtn();
		System.out.println("User is going to enter credentials");
		shoppingpage = loginpage.login(prop.getProperty("username"), prop.getProperty("password"));
		System.out.println("Clicked on Logged in button");
		shoppingpage= loginpage.submit();
	}
	
	
	@Test(priority=1)
	public void womenCategoryValidationTest(){
		shoppingpage.validateWomenCategory();
	}
	
	@Test(priority=2)
	public void validaeTshirtSelectionTest() {
		shoppingpage.validateWomenCategory();
		shoppingpage.validateTshirtSelection();
	}
	@Test(priority=3)
	public void validateSizeTest() {
		shoppingpage.validateWomenCategory();
		shoppingpage.validateTshirtSelection();
		shoppingpage.validateSize();
	}
	@Test(priority=4)
	public void validateColorTest() {
		shoppingpage.validateWomenCategory();
		shoppingpage.validateTshirtSelection();
		shoppingpage.validateSize();
		shoppingpage.validateColor();
		
	}
	@Test(priority=5)
	public void validateSelectProductTest() {
		shoppingpage.validateWomenCategory();
		shoppingpage.validateTshirtSelection();
		shoppingpage.validateSize();
		shoppingpage.validateSelectProduct();
		
	}
	@Test(priority=6)
	public void validateAddtoCardTest() {
		shoppingpage.validateWomenCategory();
		shoppingpage.validateTshirtSelection();
		shoppingpage.validateSize();
		shoppingpage.validateSelectProduct();
		shoppingpage.validateAddtoCard();
		
		
	}

	@Test(priority=7)
	public void validateProceedtoCardTest() {
		shoppingpage.validateWomenCategory();
		shoppingpage.validateTshirtSelection();
		shoppingpage.validateSize();
		shoppingpage.validateSelectProduct();
		shoppingpage.validateAddtoCard();
		shoppingpage.validateProceedToCart();
	}
	
	@AfterMethod
	public void tearDown(){
		driver.quit();
	}
	
	
	
}
