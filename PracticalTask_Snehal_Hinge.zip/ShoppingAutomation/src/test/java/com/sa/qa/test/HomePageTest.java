package com.sa.qa.test;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sa.qa.base.BaseTest;
import com.sa.qa.pages.HomePage;
import com.sa.qa.pages.LoginPage;

public class HomePageTest extends BaseTest {

	HomePage homepage;
	LoginPage loginpage;

	public HomePageTest() {
		super();
	}

	@BeforeMethod
	public void setUp() {
		initialization();
		homepage = new HomePage();
	}

	@Test(priority = 1)
	public void loginPageTitleTest() {
		String title = homepage.ValidateTitle();
		Assert.assertEquals(title, "My Store");
	}

	@Test(priority = 2)
	public void crmLogoImageTest() {
		boolean flag = homepage.validateLogo();
		Assert.assertTrue(flag);
	}

	@AfterMethod
	public void tearDown() {
		driver.quit();
	}
}
