package com.sa.qa.test;


import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sa.qa.base.BaseTest;
import com.sa.qa.pages.HomePage;
import com.sa.qa.pages.LoginPage;
import com.sa.qa.pages.ShoppingPage;

public class LoginPageTest extends BaseTest {

	LoginPage loginpage;
	ShoppingPage shoppingpage;
	HomePage homepage;
	
	public LoginPageTest(){
		super();
	}
	
	@BeforeMethod
	public void setUp(){
		initialization();
		loginpage = new LoginPage();	
	}

	@Test(priority=1)
	public void loginPageTitleTest(){
		String title = loginpage.validateLoginPageTitle();
		Assert.assertEquals(title, "My Store");
	}
		
	@Test(priority = 2)
	public void loginTest() {
		homepage = new HomePage();
		System.out.println("User is going to click on SignIn Button");
		//logger=report.createTest("Login Test");
		loginpage= homepage.ValidateLoginbtn();
		System.out.println("User is going to enter credentials");
		shoppingpage = loginpage.login(prop.getProperty("username"), prop.getProperty("password"));
		System.out.println("Clicked on Logged in button");
		shoppingpage= loginpage.submit();
		
	}


	@AfterMethod
	public void tearDown(){
		driver.quit();
	}
	

}
