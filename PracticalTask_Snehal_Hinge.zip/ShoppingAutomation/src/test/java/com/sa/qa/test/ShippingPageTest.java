package com.sa.qa.test;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sa.qa.base.BaseTest;
import com.sa.qa.pages.AddressVerifyPage;
import com.sa.qa.pages.HomePage;
import com.sa.qa.pages.LoginPage;
import com.sa.qa.pages.ShippingPage;
import com.sa.qa.pages.ShoppingPage;

public class ShippingPageTest extends BaseTest {
	LoginPage loginpage;
	ShoppingPage shoppingpage;
	HomePage homepage;
	AddressVerifyPage addressverifypage;
	ShippingPage shippingpage;

	public ShippingPageTest() {
		super();
	}

	@BeforeMethod
	public void setUp() {
		initialization();
		shoppingpage = new ShoppingPage();
		homepage = new HomePage();
		shippingpage = new ShippingPage();
		addressverifypage = new AddressVerifyPage();
		System.out.println("User is going to click on SignIn Button");
		loginpage = homepage.ValidateLoginbtn();
		System.out.println("User is going to enter credentials");
		shoppingpage = loginpage.login(prop.getProperty("username"), prop.getProperty("password"));
		System.out.println("Clicked on Logged in button");
		shoppingpage = loginpage.submit();
		shoppingpage.validateWomenCategory();
		shoppingpage.validateTshirtSelection();
		shoppingpage.validateSize();
		shoppingpage.validateSelectProduct();
		shoppingpage.validateAddtoCard();
		shoppingpage.validateProceedToCart();
		addressverifypage.validateProceedToCart();
	}

	@Test(priority = 1)
	public void validateTermsTest() {

		shippingpage.validateTerms();
	}

	@Test(priority = 2)
	public void ProceedToCheckOutBtnShippingTest() {

		shippingpage.ProceedToCheckOutBtnShipping();

	}

	@AfterMethod
	public void tearDown() {
		driver.quit();
	}
}
