package com.sa.qa.util;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.sa.qa.base.BaseTest;

public class TestUtils extends BaseTest {

	public static long PAGE_LOAD_TIMEOUT = 20;
	public static long IMPLICIT_WAIT = 20;

	public String getScreenshotPath(String Testcasename) throws Throwable {
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String destpath = System.getProperty("user.dir");
		FileUtils.copyFile(scrFile, new File(destpath + "/screenshots/" + System.currentTimeMillis() + ".png"));
		return destpath;
	}
}
