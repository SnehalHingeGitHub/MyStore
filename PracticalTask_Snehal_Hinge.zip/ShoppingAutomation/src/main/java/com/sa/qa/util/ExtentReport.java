package com.sa.qa.util;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentReport {

	public static ExtentReports extent;
	public static ExtentTest logger;

	public static ExtentReports extentReportGenerator() {

		extent = new ExtentReports();
		ExtentSparkReporter spark = new ExtentSparkReporter("target/ExtentReport.html");
		spark.config().setTheme(Theme.DARK);
		spark.config().setDocumentTitle("MyStoreApplication_Auomation");
		spark.config().setReportName("Extent Report for My Store Application");
		spark.config().setDocumentTitle("Test Results");
		extent.attachReporter(spark);
		return extent;

	}
}
