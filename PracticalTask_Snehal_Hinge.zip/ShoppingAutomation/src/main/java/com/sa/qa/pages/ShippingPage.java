package com.sa.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.sa.qa.base.BaseTest;

public class ShippingPage extends BaseTest {

	@FindBy(xpath = "//button/span[contains(text(),'Proceed to checkout')]")
	WebElement proceedToCheckOutBtnShipping;

	@FindBy(xpath = "//input[@type='checkbox']")
	WebElement agreeterms;

	public ShippingPage() {
		PageFactory.initElements(driver, this);

	}

	public void validateTerms() {
		agreeterms.click();

	}

	public PaymentPage ProceedToCheckOutBtnShipping() {

		proceedToCheckOutBtnShipping.click();

		return new PaymentPage();
	}

}
