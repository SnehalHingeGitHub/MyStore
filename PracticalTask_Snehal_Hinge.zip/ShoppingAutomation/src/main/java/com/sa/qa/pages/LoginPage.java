package com.sa.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.sa.qa.base.BaseTest;

public class LoginPage extends BaseTest {

	@FindBy(id = "email")
	WebElement email;

	@FindBy(id = "passwd")
	WebElement password;

	@FindBy(id = "SubmitLogin")
	WebElement submitBtn;

	@FindBy(name = "email_create")
	WebElement emailNewAccount;

	@FindBy(name = "SubmitCreate")
	WebElement NewAccountBtn;

	public LoginPage() {
		PageFactory.initElements(driver, this);
	}

	public ShoppingPage login(String un, String pwd) {
		email.sendKeys(un);
		password.sendKeys(pwd);

		return new ShoppingPage();
	}

	public ShoppingPage submit() {
		submitBtn.click();
		return new ShoppingPage();
	}

	public String validateLoginPageTitle() {
		return driver.getTitle();
	}
}