package com.sa.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.sa.qa.base.BaseTest;

public class PaymentPage extends BaseTest {

	@FindBy(xpath = "//a[text()='Pay by bank wire')]")
	private WebElement paybybankwire;

	@FindBy(xpath = "//a[text()='Pay by check']")
	private WebElement paybycheck;

	public PaymentPage() {
		PageFactory.initElements(driver, this);
	}

	public ConfirmOrderPage validatePaymentByCheck() {

		paybycheck.click();
		return new ConfirmOrderPage();
	}

	public ConfirmOrderPage validatePaymentByWire() {
		paybybankwire.click();
		return new ConfirmOrderPage();
	}

}
