package com.sa.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.sa.qa.base.BaseTest;

public class AddressVerifyPage extends BaseTest {

	@FindBy(xpath = "//span[text()='Proceed to checkout']")
	WebElement proceedToCheckOut;

	public AddressVerifyPage() {
		PageFactory.initElements(driver, this);

	}

	public ShippingPage validateProceedToCart() {
		proceedToCheckOut.click();

		return new ShippingPage();
	}

}
