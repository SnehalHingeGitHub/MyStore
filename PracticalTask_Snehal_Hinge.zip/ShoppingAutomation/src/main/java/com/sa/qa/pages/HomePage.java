package com.sa.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.sa.qa.base.BaseTest;

public class HomePage extends BaseTest {

	@FindBy(xpath = "//a[@class='login']")
	WebElement loginBtn;

	@FindBy(xpath = "//img[@class='logo img-responsive']")
	private WebElement Logo;

	@FindBy(id = "search_query_top")
	private WebElement searchBox;

	@FindBy(name = "submit_search")
	private WebElement searchBtn;

	public HomePage() {
		PageFactory.initElements(driver, this);
	}

	public LoginPage ValidateLoginbtn() {
		loginBtn.click();
		return new LoginPage();
	}

	public boolean validateLogo() {

		return Logo.isDisplayed();
	}

	public String ValidateTitle() {

		return driver.getTitle();

	}
}
