package com.sa.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.sa.qa.base.BaseTest;

public class ShoppingPage extends BaseTest {

	@FindBy(xpath = "//a[@class='sf-with-ul']")
	WebElement twomencategory;

	@FindBy(id = "layered_category_4")
	WebElement selectTshirt;

	@FindBy(name = "layered_id_attribute_group_2")
	WebElement size;

	@FindBy(id = "layered_id_attribute_group_13")

	WebElement tshirtcolor;

	@FindBy(xpath = "//img[@class='replace-2x img-responsive']")

	WebElement selectproduct;

	@FindBy(xpath = "//span[text()='Add to cart']")

	WebElement addtocart;

	@FindBy(xpath = "//span[contains(text(),'Proceed to checkout')]")
	WebElement proceedcheckout;

	public ShoppingPage() {
		PageFactory.initElements(driver, this);

	}

	public void validateWomenCategory() {
		twomencategory.click();
	}

	public void validateTshirtSelection() {
		selectTshirt.click();
	}

	public void validateSize() {
		size.click();
	}

	public void validateColor() {
		tshirtcolor.click();
	}

	public AddressVerifyPage validateProceedToCart() {
		proceedcheckout.click();

		return new AddressVerifyPage();
	}

	public void validateSelectProduct() {
		selectproduct.click();

	}

	public void validateAddtoCard() {
		addtocart.click();
	}

}