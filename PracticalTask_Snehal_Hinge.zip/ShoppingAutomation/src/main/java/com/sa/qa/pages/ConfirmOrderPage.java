package com.sa.qa.pages;

public class ConfirmOrderPage {

}
